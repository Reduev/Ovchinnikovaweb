from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib import messages
from django.db.models import Q
from .models import News, Comment
from .forms import RegisterForm, NewsForm, CommentForm


def is_staff_user(user):
    return user.is_staff or user.is_superuser


def home(request):
    latest_news = News.objects.all()[:3]
    return render(request, 'news/home.html', {'latest_news': latest_news})


def contacts(request):
    return render(request, 'news/contacts.html')


def news_list(request):
    news_items = News.objects.all()
    search_query = request.GET.get('search', '')
    sort_order = request.GET.get('sort', 'desc')

    if search_query:
        news_items = news_items.filter(Q(title__icontains=search_query) | Q(content__icontains=search_query))

    if sort_order == 'asc':
        news_items = news_items.order_by('pub_date')
    else:
        news_items = news_items.order_by('-pub_date')

    return render(request, 'news/news_list.html', {
        'news_items': news_items,
        'search_query': search_query,
        'current_sort': sort_order
    })


def news_detail(request, news_id):
    news_item = get_object_or_404(News, id=news_id)
    comments = news_item.comments.filter(is_active=True)

    if request.method == 'POST' and request.user.is_authenticated:
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.news = news_item
            comment.author = request.user
            comment.save()
            messages.success(request, 'Комментарий добавлен!')
            return redirect('news_detail', news_id=news_id)
    else:
        form = CommentForm()

    return render(request, 'news/news_detail.html', {
        'news_item': news_item,
        'comments': comments,
        'form': form
    })


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Регистрация успешно завершена!')
            return redirect('home')
    else:
        form = RegisterForm()
    return render(request, 'news/registration/register.html', {'form': form})


def user_login(request):
    if request.method == 'POST':
        from django.contrib.auth import authenticate
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'Добро пожаловать, {user.username}!')
            return redirect('home')
        else:
            messages.error(request, 'Неверное имя пользователя или пароль.')
    return render(request, 'news/registration/login.html')


def user_logout(request):
    logout(request)
    messages.success(request, 'Вы вышли из системы.')
    return redirect('home')


@login_required
def profile(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Пароль успешно изменен!')
            return redirect('profile')
    else:
        form = PasswordChangeForm(request.user)

    user_comments = request.user.comments.all().select_related('news')[:10]

    return render(request, 'news/profile.html', {
        'form': form,
        'user_comments': user_comments
    })


@login_required
@user_passes_test(is_staff_user)
def news_create(request):
    if request.method == 'POST':
        form = NewsForm(request.POST, request.FILES)
        if form.is_valid():
            news = form.save(commit=False)
            news.author = request.user
            news.save()
            messages.success(request, 'Новость успешно создана!')
            return redirect('news_detail', news_id=news.id)
    else:
        form = NewsForm()
    return render(request, 'news/news_form.html', {'form': form, 'title': 'Создание новости'})


@login_required
@user_passes_test(is_staff_user)
def news_edit(request, news_id):
    news_item = get_object_or_404(News, id=news_id)
    if request.method == 'POST':
        form = NewsForm(request.POST, request.FILES, instance=news_item)
        if form.is_valid():
            form.save()
            messages.success(request, 'Новость успешно обновлена!')
            return redirect('news_detail', news_id=news_item.id)
    else:
        form = NewsForm(instance=news_item)
    return render(request, 'news/news_form.html',
                  {'form': form, 'title': 'Редактирование новости', 'news_item': news_item})


@login_required
@user_passes_test(is_staff_user)
def news_delete(request, news_id):
    news_item = get_object_or_404(News, id=news_id)
    if request.method == 'POST':
        news_item.delete()
        messages.success(request, 'Новость успешно удалена!')
        return redirect('news_list')
    return render(request, 'news/news_confirm_delete.html', {'news_item': news_item})