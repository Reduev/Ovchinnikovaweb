from django.contrib import admin
from .models import News, Comment

@admin.register(News)
class NewsAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'pub_date', 'created_at']
    list_filter = ['pub_date', 'author']
    search_fields = ['title', 'content']
    date_hierarchy = 'pub_date'

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['news', 'author', 'created_date', 'is_active']
    list_filter = ['is_active', 'created_date']
    search_fields = ['text', 'author__username']